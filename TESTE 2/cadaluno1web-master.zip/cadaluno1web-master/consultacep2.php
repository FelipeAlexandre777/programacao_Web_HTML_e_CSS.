<?php
include 'conecta.php'; //30261000   12013000   09011000     
$op = "";

if(isset($_POST['txtCEP'])){
    $cep = $_POST['txtCEP'];
}else if(isset($_GET['txtCEP'])){
    $cep = $_GET['txtCEP'];
}

if(isset($_POST['txtOp'])){
	$op = $_POST['txtOp'];
}

$cidade=""; $estado=""; $endereco=""; $bairro="";
$sql = " SELECT cep.*, C.nome_cidade, E.nome_estado  FROM academico.ceps cep JOIN academico.cidades C ON 
CEP.id_cidade = C.id_cidade JOIN academico.estados E ON C.id_estado = E.id_estado 
WHERE cep.cep = '$cep' ";

//echo $sql."<br/>";
$result = pg_query($conexao, $sql);

if($linha = pg_fetch_assoc($result)){
	$cidade=$linha['nome_cidade']; 
	$estado=$linha['nome_estado']; 
	$endereco=$linha['logradouro'];
	$bairro=$linha['bairro'];
}
//echo "cidade: $cidade <br/>"; 
//echo "estado: $estado <br/>"; 
//echo "endereco: $endereco <br/>";
//echo "bairro: $bairro <br/>";
header('Content-Type: application/json; charset=utf-8');
//echo "{\"cidade\": \"$cidade\", \"estado\": \"$estado\", \"endereco\": \"$endereco\", \"bairro\": \"$bairro\" }";
$arrayRes = ['cidade' => $cidade, 'estado' => $estado, 'bairro' => $bairro, 'endereco' => $endereco];
echo json_encode($arrayRes,JSON_UNESCAPED_UNICODE);
pg_close($conexao);
?>
