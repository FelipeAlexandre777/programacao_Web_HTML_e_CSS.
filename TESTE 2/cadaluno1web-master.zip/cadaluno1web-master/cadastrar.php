<?php

include 'conecta.php';

$nome = $_POST['txtNome'];
$endereco = $_POST['txtEndereco'];
$fone = $_POST['txtFone'];
$email = $_POST['txtEmail'];
$cep = $_POST['txtCEP'];
$estado = $_POST['txtEstado'];
$cidade = $_POST['txtCidade'];

$sql = "INSERT INTO academico.alunos (nome, endereco, telefone, email, cep, estado, cidade) VALUES
	('$nome', '$endereco', '$fone', '$email', '$cep', '$estado', '$cidade');";

//echo "\n<br/>";
//echo $sql;
//echo "<br/>\n";

$result = pg_query($conexao, $sql);

if(!$result){
	die("Erro no cadastro");
}
pg_close($conexao);
echo "<html><head><title>Cadastro de Alunos</title></head>";
echo "<body>";
echo "<script>
	function cadastrar(){ 
		window.location.href='cadastro.html';
	}
	function listar(){
		window.location.href='listar.php';
	}
	</script>";
echo "<h1 style='color: blue'>Aluno $nome cadastrado com sucesso!</h1><br/>";
echo "<input type='button' value='Ir para pag. de Cadastro' onclick='cadastrar();'/>";
echo "<input type='button' value='Ir para pag. de Listagem' onclick='listar();'/>";
echo "</body>";
echo "</html>";

?>
