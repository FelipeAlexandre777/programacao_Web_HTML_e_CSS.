<?php 
$op="";
$cep="";$nome="";
if(isset($_POST['txtOp'])){
  $op = $_POST['txtOp'];
  $cep = $_POST['txtCEP'];
  $nome = $_POST['txtNome'];

  if($op=='consultacep'){
    include 'consultacep.php';
  }
}

?>
<html>
	<head><title>Cadastro de Alunos</title>
	</head>
	<body>

 <script>
	function listar(){
//		alert('Pagina de listagem chamda com sucesso! Mentira! Eh soh um alert!');
		frmCadastro.action='listar.php';
		frmCadastro.submit();
	}
	function buscaCEP(){
		//alert('Busca CEP!');
		frmCadastro.txtOp.value='consultacep';
		//frmCadastro.action='consultacep.php';
		frmCadastro.action='cad.php';
		frmCadastro.submit();
	}	
</script>

	<form method="POST" name="frmCadastro" id="frmCadastro" action="cadastrar.php">
		Nome:
		<input type="text" id="txtNome" name="txtNome" value="<?php echo $nome?>"/> <br/>
		CEP:
		<input type="text" id="txtCEP" name="txtCEP" onblur="javascript:buscaCEP()" value="<?php echo $cep;?>" /> <br/>
		Endere&ccedil;o:
		<?php
		if($op==""){
		?>
		<input type="text" id="txtEndereco" name="txtEndereco" value=""/><br/>
		<?php
		}else if($op=="consultacep"){
		?>
			<input type="text" id="txtEndereco" name="txtEndereco" value="<?php echo $endereco; ?>" /> <br/>
		<?php
		}
		?>
		Bairro:
		<input type="text" id="txtBairro" name="txtBairro" value="<?php echo $bairro;?>" /> <br/>
		Estado:
		<input type="text" id="txtEstado" name="txtEstado" value="<?php echo $estado;?> "/> <br/>
		Cidade:
		<input type="text" id="txtCidade" name="txtCidade" value="<?php echo $estado;?>"/> <br/>
		Telefone:
		<input type="text" id="txtFone" size="15" maxlength=15 name="txtFone"/> <br/>
		Email:
		<input type="text" id="txtEmail" name="txtEmail"/> <br/>
		<input type="submit" value="Cadastrar"/>
		<input type="button" value="Listar" onclick='javascript:listar();' />
    <input type="hidden" value="" id="txtOp" name="txtOp"/> 
		
	</form>

	</body>

</html>

