<?php
// conexao.php
$host = '10.90.24.54';
$porta = '5432';
$db = 'aula';
$usuario = 'aula';
$senha = 'aula';
$conexao="";
//try {
//    $conevao = new PDO("pgsql:host=$host;port=$porta;dbname=$db", $usuario, $senha);
//    $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//} catch (PDOException $e) {
//    echo "Erro de conexão: " . $e->getMessage();
//    die();
//}

$conexao = pg_connect("host=$host dbname=$db user=$usuario password=$senha");

if(!$conexao){
	die("Erro na conexão");
}

?>

