<?php 
$op="";
$cep="";$nome="";
if(isset($_POST['txtOp'])){
  $op = $_POST['txtOp'];
  $cep = $_POST['txtCEP'];
  $nome = $_POST['txtNome'];

  if($op=='consultacep'){
    include 'consultacep.php';
  }
}

?>
<html>
	<head><title>Cadastro de Alunos</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
	</head>
	<body>

 <script>
	function listar(){
		frmCadastro.action='listar.php';
		frmCadastro.submit();
	}
	function buscaCEP(){ //busca normal
		//alert('Busca CEP!');
		frmCadastro.txtOp.value='consultacep';
		//frmCadastro.action='consultacep.php';
		frmCadastro.action='cad.php';
		frmCadastro.submit();
	}
	function consultaCEP() {
		//alert('agora CHAMOU');
		console.log("Hello Hello, here I came!"+$('#txtCEP').val());
		$.ajax( {
			url: 'consultacep2.php?txtCEP='+$('#txtCEP').val(),
			type: 'POST',
			data: JSON.stringify($('#txtCEP').val()),
			contentType: 'application/json; charset=utf-8',
			dataType: 'json',
			success: function(response){
				console.log("hora da resposta!");
				console.log(response);
				var teste=response.endereco;
				console.log("Teste: "+teste);
				//var dados = JSON.parse(response);
				var dados = response;
				console.log("dados: "+dados);
				$('#txtEndereco').val(dados.endereco);
				$('#txtBairro').val(dados.bairro);
				$('#txtCidade').val(dados.cidade);
				$('#txtEstado').val(dados.estado);
			},
			error: function(param1, status, msg){
				console.log("Função de erro - status: " + status + " param1: "+JSON.stringify(param1)+" mensagem de erro: " + msg);
			},
			
			complete: function(param1, status){
				console.log("Sei que deu erro, mas vamos ver o status: " + status + " param1: "+JSON.stringify(param1));			
			}
			
		
		} );
	
	}
	
</script>

	<form method="POST" name="frmCadastro" id="frmCadastro" action="cadastrar.php">
		Nome:
		<input type="text" id="txtNome" name="txtNome" value="<?php echo $nome?>"/> <br/>
		CEP:
		<input type="text" id="txtCEP" name="txtCEP" onblur="javascript:consultaCEP()" value="<?php echo $cep;?>" /> <br/>
		Endere&ccedil;o:
		<?php
		if($op==""){
		?>
		<input type="text" id="txtEndereco" name="txtEndereco" value=""/><br/>
		<?php
		}else if($op=="consultacep"){
		?>
			<input type="text" id="txtEndereco" name="txtEndereco" value="<?php echo $endereco; ?>" /> <br/>
		<?php
		}
		?>
		Bairro:
		<input type="text" id="txtBairro" name="txtBairro" value="<?php echo $bairro;?>" /> <br/>
		Estado:
		<input type="text" id="txtEstado" name="txtEstado" value="<?php echo $estado;?> "/> <br/>
		Cidade:
		<input type="text" id="txtCidade" name="txtCidade" value="<?php echo $estado;?>"/> <br/>
		Telefone:
		<input type="text" id="txtFone" size="15" maxlength=15 name="txtFone"/> <br/>
		Email:
		<input type="text" id="txtEmail" name="txtEmail"/> <br/>
		<input type="submit" value="Cadastrar"/>
		<input type="button" value="Listar" onclick='javascript:listar();' />
    <input type="hidden" value="" id="txtOp" name="txtOp"/> 
		
	</form>

	</body>

</html>

