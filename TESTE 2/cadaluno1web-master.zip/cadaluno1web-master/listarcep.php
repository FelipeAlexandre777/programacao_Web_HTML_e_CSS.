<?php

include 'conecta.php';

$sql = "SELECT * FROM academico.ceps ORDER BY RANDOM() LIMIT 10 ";
$resultado = pg_query($conexao,$sql);

while($linha = pg_fetch_assoc($resultado)){
    echo "CEP: ".$linha['cep']." ";
    echo "End.: ".$linha['logradouro']." ";
    echo "Bairro: ".$linha['bairro']."<br/>";
}
pg_close($conexao);

?>
