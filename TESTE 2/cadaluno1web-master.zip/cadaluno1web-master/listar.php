<?php
echo "<html>";
include 'conecta.php';

$sql = " SELECT * FROM academico.alunos";

$result = pg_query($conexao, $sql);

if($result){


	while($linha = pg_fetch_assoc($result)){

		echo "<label style='color:blue;'><strong>".$linha['nome']."</strong></label>"; echo "&nbsp;";
		echo $linha['endereco']; echo "&nbsp;";
		echo $linha['telefone']; echo "&nbsp;";
		echo $linha['email']; echo "&nbsp;";
		echo $linha['cidade']; echo "&nbsp;";
		echo $linha['cep']; echo "&nbsp;";
		echo $linha['estado']; echo "&nbsp;";		
		echo "<br/>"; echo "\n";
	
	}

}else{
	echo "erro"; echo pg_last_error();
}
pg_close($conexao);
echo "<form>";
echo "<input type='button' value='VOLTAR' onclick='history.back();'" ;
echo "</form";
echo "</html>";

?>
